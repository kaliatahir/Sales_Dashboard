// ============================================================
// SALES ANALYTICS DASHBOARD
// ============================================================

const STORAGE_KEY =
    "salesDashboardData";


let salesData = [];

let filteredData = [];


// Chart instances

let salesTrendChart = null;

let regionChart = null;

let categoryChart = null;

let repChart = null;

let customerChart = null;

let channelChart = null;


// ============================================================
// INITIALIZATION
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadCSV();

        setupFilterListeners();

    }
);


// ============================================================
// LOAD DATA
// ============================================================

async function loadCSV() {

    try {

        const savedData =
            localStorage.getItem(
                STORAGE_KEY
            );


        if (savedData) {

            salesData =
                JSON.parse(
                    savedData
                );

            console.log(
                "Loaded data from localStorage:",
                salesData.length
            );

        }

        else {

            const response =
                await fetch(
                    "data/sales_data.csv"
                );


            if (!response.ok) {

                throw new Error(
                    "Unable to load sales_data.csv"
                );

            }


            const csvText =
                await response.text();


            salesData =
                parseCSV(
                    csvText
                );


            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(
                    salesData
                )
            );


            console.log(
                "Loaded initial CSV:",
                salesData.length
            );

        }


        filteredData =
            [...salesData];


        initializeDashboard();

    }

    catch (error) {

        console.error(
            error
        );


        alert(
            "Unable to load sales data.\n\n" +
            "Make sure sales_data.csv exists inside:\n" +
            "data/sales_data.csv\n\n" +
            "Also run the project using Live Server."
        );

    }

}


// ============================================================
// CSV PARSER
// ============================================================

function parseCSV(csvText) {

    const rows = [];

    let row = [];

    let value = "";

    let insideQuotes = false;


    for (
        let i = 0;
        i < csvText.length;
        i++
    ) {

        const char =
            csvText[i];

        const nextChar =
            csvText[i + 1];


        if (
            char === '"' &&
            insideQuotes &&
            nextChar === '"'
        ) {

            value += '"';

            i++;

        }

        else if (
            char === '"'
        ) {

            insideQuotes =
                !insideQuotes;

        }

        else if (
            char === "," &&
            !insideQuotes
        ) {

            row.push(
                value.trim()
            );

            value = "";

        }

        else if (
            (
                char === "\n" ||
                char === "\r"
            ) &&
            !insideQuotes
        ) {

            if (
                char === "\r" &&
                nextChar === "\n"
            ) {

                i++;

            }


            row.push(
                value.trim()
            );

            value = "";


            if (
                row.some(
                    cell =>
                        cell !== ""
                )
            ) {

                rows.push(
                    row
                );

            }


            row = [];

        }

        else {

            value += char;

        }

    }


    if (
        value !== "" ||
        row.length > 0
    ) {

        row.push(
            value.trim()
        );


        if (
            row.some(
                cell =>
                    cell !== ""
            )
        ) {

            rows.push(
                row
            );

        }

    }


    if (
        rows.length === 0
    ) {

        return [];

    }


    const headers =
        rows[0];


    return rows
        .slice(1)
        .map(
            row => {

                const object = {};


                headers.forEach(
                    (
                        header,
                        index
                    ) => {

                        object[header] =
                            row[index] || "";

                    }
                );


                return object;

            }
        );

}


// ============================================================
// INITIALIZE DASHBOARD
// ============================================================

function initializeDashboard() {

    populateFilters();

    updateDashboard();

}


// ============================================================
// FILTER LISTENERS
// ============================================================

function setupFilterListeners() {

    const filters = [

        "dateFilter",

        "regionFilter",

        "categoryFilter",

        "repFilter",

        "channelFilter"

    ];


    filters.forEach(
        id => {

            const element =
                document.getElementById(
                    id
                );


            if (element) {

                element.addEventListener(
                    "change",
                    applyFilters
                );

            }

        }
    );


    const resetButton =
        document.getElementById(
            "resetFilters"
        );


    if (resetButton) {

        resetButton.addEventListener(
            "click",
            resetFilters
        );

    }

}


// ============================================================
// POPULATE FILTERS
// ============================================================

function populateFilters() {

    populateSelect(
        "regionFilter",
        "Region"
    );


    populateSelect(
        "categoryFilter",
        "Product_Category"
    );


    populateSelect(
        "repFilter",
        "Sales_Rep"
    );


    populateSelect(
        "channelFilter",
        "Sales_Channel"
    );

}


// ============================================================
// POPULATE SELECT
// ============================================================

function populateSelect(
    selectId,
    fieldName
) {

    const select =
        document.getElementById(
            selectId
        );


    if (!select) {

        return;

    }


    let currentValues = [];


    if (select.multiple) {

        currentValues = [
            ...select.selectedOptions
        ]
            .map(
                option => option.value
            );

    } else {

        currentValues = [
            select.value
        ];

    }


    while (
        select.options.length > 1
    ) {

        select.remove(1);

    }


    const values =
        [
            ...new Set(
                salesData
                    .map(
                        item =>
                            item[fieldName]
                    )
                    .filter(
                        value =>
                            value !==
                            undefined &&
                            value !==
                            null &&
                            value !==
                            ""
                    )
            )
        ]
        .sort();


    values.forEach(
        value => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                value;


            option.textContent =
                value;


            if (
                currentValues.includes(
                    value
                )
            ) {

                option.selected =
                    true;

            }


            select.appendChild(
                option
            );

        }
    );

}


// ============================================================
// APPLY FILTERS
// ============================================================

function applyFilters() {

    const region =
        getValue(
            "regionFilter"
        );


    const category =
        getValue(
            "categoryFilter"
        );


    const rep =
        getValue(
            "repFilter"
        );


    const channel =
        getValue(
            "channelFilter"
        );


    const dateRange =
        getValue(
            "dateFilter"
        );


    filteredData =
        salesData.filter(
            item => {

                if (
                    region &&
                    item.Region !== region
                ) {

                    return false;

                }


                if (
                    category &&
                    item.Product_Category !==
                    category
                ) {

                    return false;

                }


                if (
                    rep &&
                    rep.length > 0 &&
                    !rep.includes(
                        item.Sales_Rep
                    )
                ) {

                    return false;

                }


                if (
                    channel &&
                    item.Sales_Channel !==
                    channel
                ) {

                    return false;

                }


                if (
                    dateRange !== "all"
                ) {

                    const days =
                        parseInt(
                            dateRange
                        );


                    const saleDate =
                        parseSaleDate(
                            item.Sale_Date
                        );


                    if (!saleDate) {

                        return true;

                    }


                    const today =
                        new Date();


                    const cutoff =
                        new Date(
                            today
                        );


                    cutoff.setDate(
                        today.getDate() -
                        days
                    );


                    cutoff.setHours(
                        0,
                        0,
                        0,
                        0
                    );


                    if (
                        saleDate <
                        cutoff
                    ) {

                        return false;

                    }

                }


                return true;

            }
        );


    updateDashboard();

}


// ============================================================
// RESET FILTERS
// ============================================================

function resetFilters() {

    const filters = [

        "dateFilter",

        "regionFilter",

        "categoryFilter",

        "repFilter",

        "channelFilter"

    ];


    filters.forEach(
        id => {

            const element =
                document.getElementById(
                    id
                );


            if (element) {

                if (element.multiple) {

                    [
                        ...element.options
                    ]
                        .forEach(
                            option => option.selected = false
                        );

                } else {

                    element.selectedIndex =
                        0;

                }

            }

        }
    );


    filteredData =
        [...salesData];


    updateDashboard();

}


// ============================================================
// UPDATE DASHBOARD
// ============================================================

function updateDashboard() {

    updateKPIs();

    updateCharts();

    updateInsights();

    updateTable();

}


// ============================================================
// KPI
// ============================================================

function updateKPIs() {

    const totalSales =
        filteredData.reduce(
            (
                total,
                item
            ) => {

                return (
                    total +
                    parseNumber(
                        item.Sales_Amount
                    )
                );

            },
            0
        );


    const totalQuantity =
        filteredData.reduce(
            (
                total,
                item
            ) => {

                return (
                    total +
                    parseNumber(
                        item.Quantity_Sold
                    )
                );

            },
            0
        );


    const averageSale =
        filteredData.length > 0
            ? totalSales /
              filteredData.length
            : 0;


    const reps =
        new Set(
            filteredData
                .map(
                    item =>
                        item.Sales_Rep
                )
                .filter(Boolean)
        );


    setText(
        "totalSales",
        formatCurrency(
            totalSales
        )
    );


    setText(
        "totalQuantity",
        totalQuantity.toLocaleString()
    );


    setText(
        "averageSale",
        formatCurrency(
            averageSale
        )
    );


    setText(
        "totalReps",
        reps.size.toLocaleString()
    );

}


// ============================================================
// CHARTS
// ============================================================

function updateCharts() {

    createSalesTrendChart();

    createRegionChart();

    createCategoryChart();

    createRepChart();

    createCustomerChart();

    createChannelChart();

}


// ============================================================
// SALES TREND
// ============================================================

function createSalesTrendChart() {

    const canvas =
        document.getElementById(
            "salesTrendChart"
        );


    if (!canvas) {

        return;

    }


    const monthlyData = {};


    filteredData.forEach(
        item => {

            const date =
                parseSaleDate(
                    item.Sale_Date
                );


            if (!date) {

                return;

            }


            const key =
                `${date.getFullYear()}-${String(
                    date.getMonth() + 1
                ).padStart(2, "0")}`;


            if (
                !monthlyData[key]
            ) {

                monthlyData[key] = 0;

            }


            monthlyData[key] +=
                parseNumber(
                    item.Sales_Amount
                );

        }
    );


    const sortedKeys =
        Object.keys(
            monthlyData
        ).sort();


    const labels =
        sortedKeys.map(
            key => {

                const [
                    year,
                    month
                ] =
                    key.split("-");


                return new Date(
                    parseInt(year),
                    parseInt(month) - 1
                ).toLocaleDateString(
                    "en-US",
                    {
                        month: "short",
                        year: "numeric"
                    }
                );

            }
        );


    const values =
        sortedKeys.map(
            key =>
                monthlyData[key]
        );


    if (
        salesTrendChart
    ) {

        salesTrendChart.destroy();

    }


    const ctx =
        canvas.getContext(
            "2d"
        );


    const gradient =
        ctx.createLinearGradient(
            0,
            0,
            0,
            300
        );


    gradient.addColorStop(
        0,
        "rgba(37, 99, 235, 0.25)"
    );


    gradient.addColorStop(
        1,
        "rgba(37, 99, 235, 0.01)"
    );


    salesTrendChart =
        new Chart(
            ctx,
            {

                type: "line",

                data: {

                    labels,

                    datasets: [

                        {

                            label:
                                "Sales",

                            data:
                                values,

                            borderColor:
                                "#2563eb",

                            backgroundColor:
                                gradient,

                            borderWidth:
                                3,

                            fill:
                                true,

                            tension:
                                0.4,

                            pointRadius:
                                3,

                            pointHoverRadius:
                                6,

                            pointBackgroundColor:
                                "#2563eb",

                            pointBorderColor:
                                "#ffffff",

                            pointBorderWidth:
                                2

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    interaction: {

                        intersect:
                            false,

                        mode:
                            "index"

                    },

                    plugins: {

                        legend: {

                            display:
                                false

                        },

                        tooltip: {

                            backgroundColor:
                                "#111827",

                            padding:
                                12,

                            cornerRadius:
                                8,

                            displayColors:
                                false,

                            callbacks: {

                                label:
                                    function (
                                        context
                                    ) {

                                        return (
                                            "Sales: " +
                                            formatCurrency(
                                                context.parsed.y
                                            )
                                        );

                                    }

                            }

                        }

                    },

                    scales: {

                        x: {

                            grid: {

                                display:
                                    false

                            },

                            ticks: {

                                color:
                                    "#9ca3af",

                                maxTicksLimit:
                                    8

                            }

                        },

                        y: {

                            beginAtZero:
                                true,

                            grid: {

                                color:
                                    "#eef2f7"

                            },

                            ticks: {

                                color:
                                    "#9ca3af",

                                callback:
                                    function (
                                        value
                                    ) {

                                        return formatCompactCurrency(
                                            value
                                        );

                                    }

                            }

                        }

                    }

                }

            }
        );

}


// ============================================================
// REGION CHART
// ============================================================

function createRegionChart() {

    const canvas =
        document.getElementById(
            "regionChart"
        );


    if (!canvas) {

        return;

    }


    const data =
        groupSalesBy(
            "Region"
        );


    const labels =
        Object.keys(
            data
        );


    const values =
        Object.values(
            data
        );


    if (
        regionChart
    ) {

        regionChart.destroy();

    }


    regionChart =
        new Chart(
            canvas,
            {

                type: "bar",

                data: {

                    labels,

                    datasets: [

                        {

                            label:
                                "Sales",

                            data:
                                values,

                            backgroundColor:
                                "#2563eb",

                            borderRadius:
                                7,

                            borderSkipped:
                                false,

                            barThickness:
                                25

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    indexAxis:
                        "y",

                    plugins: {

                        legend: {

                            display:
                                false

                        },

                        tooltip: {

                            backgroundColor:
                                "#111827",

                            callbacks: {

                                label:
                                    context =>
                                        formatCurrency(
                                            context.parsed.x
                                        )

                            }

                        }

                    },

                    scales: {

                        x: {

                            beginAtZero:
                                true,

                            grid: {

                                color:
                                    "#eef2f7"

                            },

                            ticks: {

                                color:
                                    "#9ca3af",

                                callback:
                                    value =>
                                        formatCompactCurrency(
                                            value
                                        )

                            }

                        },

                        y: {

                            grid: {

                                display:
                                    false

                            },

                            ticks: {

                                color:
                                    "#4b5563"

                            }

                        }

                    }

                }

            }
        );

}


// ============================================================
// CATEGORY CHART
// ============================================================

function createCategoryChart() {

    const canvas =
        document.getElementById(
            "categoryChart"
        );


    if (!canvas) {

        return;

    }


    const data =
        groupSalesBy(
            "Product_Category"
        );


    const labels =
        Object.keys(
            data
        );


    const values =
        Object.values(
            data
        );


    if (
        categoryChart
    ) {

        categoryChart.destroy();

    }


    categoryChart =
        new Chart(
            canvas,
            {

                type:
                    "doughnut",

                data: {

                    labels,

                    datasets: [

                        {

                            data:
                                values,

                            backgroundColor: [

                                "#2563eb",

                                "#7c3aed",

                                "#06b6d4",

                                "#f59e0b",

                                "#10b981",

                                "#ef4444"

                            ],

                            borderWidth:
                                3,

                            borderColor:
                                "#ffffff",

                            hoverOffset:
                                8

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    cutout:
                        "68%",

                    plugins: {

                        legend: {

                            position:
                                "bottom",

                            labels: {

                                usePointStyle:
                                    true,

                                pointStyle:
                                    "circle",

                                padding:
                                    16,

                                color:
                                    "#4b5563",

                                font: {

                                    size:
                                        11

                                }

                            }

                        },

                        tooltip: {

                            backgroundColor:
                                "#111827",

                            callbacks: {

                                label:
                                    function (
                                        context
                                    ) {

                                        const total =
                                            context.dataset.data
                                                .reduce(
                                                    (
                                                        a,
                                                        b
                                                    ) =>
                                                        a + b,
                                                    0
                                                );


                                        const percentage =
                                            total
                                                ? (
                                                    context.parsed /
                                                    total *
                                                    100
                                                )
                                                : 0;


                                        return (
                                            context.label +
                                            ": " +
                                            formatCurrency(
                                                context.parsed
                                            ) +
                                            " (" +
                                            percentage.toFixed(
                                                1
                                            ) +
                                            "%)"
                                        );

                                    }

                            }

                        }

                    }

                }

            }
        );

}


// ============================================================
// SALES REP CHART
// ============================================================

function createRepChart() {

    const canvas =
        document.getElementById(
            "repChart"
        );


    if (!canvas) {

        return;

    }


    const data =
        groupSalesBy(
            "Sales_Rep"
        );


    const sorted =
        Object.entries(
            data
        )
        .sort(
            (
                a,
                b
            ) =>
                b[1] - a[1]
        )
        .slice(
            0,
            7
        );


    const labels =
        sorted.map(
            item =>
                item[0]
        );


    const values =
        sorted.map(
            item =>
                item[1]
        );


    if (
        repChart
    ) {

        repChart.destroy();

    }


    repChart =
        new Chart(
            canvas,
            {

                type:
                    "bar",

                data: {

                    labels,

                    datasets: [

                        {

                            data:
                                values,

                            backgroundColor:
                                "#7c3aed",

                            borderRadius:
                                6,

                            borderSkipped:
                                false,

                            barThickness:
                                20

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    indexAxis:
                        "y",

                    plugins: {

                        legend: {

                            display:
                                false

                        },

                        tooltip: {

                            backgroundColor:
                                "#111827",

                            callbacks: {

                                label:
                                    context =>
                                        formatCurrency(
                                            context.parsed.x
                                        )

                            }

                        }

                    },

                    scales: {

                        x: {

                            beginAtZero:
                                true,

                            grid: {

                                color:
                                    "#eef2f7"

                            },

                            ticks: {

                                color:
                                    "#9ca3af",

                                callback:
                                    value =>
                                        formatCompactCurrency(
                                            value
                                        )

                            }

                        },

                        y: {

                            grid: {

                                display:
                                    false

                            },

                            ticks: {

                                color:
                                    "#4b5563"

                            }

                        }

                    }

                }

            }
        );

}


// ============================================================
// CUSTOMER CHART
// ============================================================

function createCustomerChart() {

    const canvas =
        document.getElementById(
            "customerChart"
        );


    if (!canvas) {

        return;

    }


    const data =
        groupSalesBy(
            "Customer_Type"
        );


    const labels =
        Object.keys(
            data
        );


    const values =
        Object.values(
            data
        );


    if (
        customerChart
    ) {

        customerChart.destroy();

    }


    customerChart =
        new Chart(
            canvas,
            {

                type:
                    "doughnut",

                data: {

                    labels,

                    datasets: [

                        {

                            data:
                                values,

                            backgroundColor: [

                                "#2563eb",

                                "#10b981",

                                "#f59e0b",

                                "#7c3aed"

                            ],

                            borderWidth:
                                3,

                            borderColor:
                                "#ffffff",

                            hoverOffset:
                                8

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    cutout:
                        "68%",

                    plugins: {

                        legend: {

                            position:
                                "bottom",

                            labels: {

                                usePointStyle:
                                    true,

                                padding:
                                    18,

                                color:
                                    "#4b5563"

                            }

                        },

                        tooltip: {

                            backgroundColor:
                                "#111827",

                            callbacks: {

                                label:
                                    context =>
                                        context.label +
                                        ": " +
                                        formatCurrency(
                                            context.parsed
                                        )

                            }

                        }

                    }

                }

            }
        );

}


// ============================================================
// CHANNEL CHART
// ============================================================

function createChannelChart() {

    const canvas =
        document.getElementById(
            "channelChart"
        );


    if (!canvas) {

        return;

    }


    const data =
        groupSalesBy(
            "Sales_Channel"
        );


    const labels =
        Object.keys(
            data
        );


    const values =
        Object.values(
            data
        );


    if (
        channelChart
    ) {

        channelChart.destroy();

    }


    channelChart =
        new Chart(
            canvas,
            {

                type:
                    "bar",

                data: {

                    labels,

                    datasets: [

                        {

                            label:
                                "Sales",

                            data:
                                values,

                            backgroundColor:
                                [
                                    "#06b6d4",
                                    "#2563eb"
                                ],

                            borderRadius:
                                8,

                            borderSkipped:
                                false

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,

                    plugins: {

                        legend: {

                            display:
                                false

                        },

                        tooltip: {

                            backgroundColor:
                                "#111827",

                            callbacks: {

                                label:
                                    context =>
                                        formatCurrency(
                                            context.parsed.y
                                        )

                            }

                        }

                    },

                    scales: {

                        x: {

                            grid: {

                                display:
                                    false

                            },

                            ticks: {

                                color:
                                    "#4b5563"

                            }

                        },

                        y: {

                            beginAtZero:
                                true,

                            grid: {

                                color:
                                    "#eef2f7"

                            },

                            ticks: {

                                color:
                                    "#9ca3af",

                                callback:
                                    value =>
                                        formatCompactCurrency(
                                            value
                                        )

                            }

                        }

                    }

                }

            }
        );

}


// ============================================================
// GROUP SALES
// ============================================================

function groupSalesBy(
    field
) {

    const result = {};


    filteredData.forEach(
        item => {

            const key =
                item[field] ||
                "Unknown";


            if (
                !result[key]
            ) {

                result[key] = 0;

            }


            result[key] +=
                parseNumber(
                    item.Sales_Amount
                );

        }
    );


    return result;

}


// ============================================================
// INSIGHTS
// ============================================================

function updateInsights() {

    const regionData =
        groupSalesBy(
            "Region"
        );


    const categoryData =
        groupSalesBy(
            "Product_Category"
        );


    const repData =
        groupSalesBy(
            "Sales_Rep"
        );


    const topRegion =
        getTopEntry(
            regionData
        );


    const topCategory =
        getTopEntry(
            categoryData
        );


    const topRep =
        getTopEntry(
            repData
        );


    const highestSale =
        filteredData.reduce(
            (
                max,
                item
            ) => {

                const amount =
                    parseNumber(
                        item.Sales_Amount
                    );


                return amount >
                    max
                    ? amount
                    : max;

            },
            0
        );


    setText(
        "topRegion",
        topRegion
            ? `${topRegion[0]} — ${formatCurrency(topRegion[1])}`
            : "—"
    );


    setText(
        "topCategory",
        topCategory
            ? `${topCategory[0]} — ${formatCurrency(topCategory[1])}`
            : "—"
    );


    setText(
        "topRep",
        topRep
            ? `${topRep[0]} — ${formatCurrency(topRep[1])}`
            : "—"
    );


    setText(
        "highestSale",
        formatCurrency(
            highestSale
        )
    );

}


// ============================================================
// TOP ENTRY
// ============================================================

function getTopEntry(
    object
) {

    const entries =
        Object.entries(
            object
        );


    if (
        entries.length === 0
    ) {

        return null;

    }


    return entries.sort(
        (
            a,
            b
        ) =>
            b[1] - a[1]
    )[0];

}


// ============================================================
// TABLE
// ============================================================

function updateTable() {

    const tableBody =
        document.getElementById(
            "salesTableBody"
        );


    if (!tableBody) {

        return;

    }


    tableBody.innerHTML = "";


    const recentData =
        [...filteredData]
            .sort(
                (
                    a,
                    b
                ) => {

                    const dateA =
                        parseSaleDate(
                            a.Sale_Date
                        );


                    const dateB =
                        parseSaleDate(
                            b.Sale_Date
                        );


                    if (
                        !dateA ||
                        !dateB
                    ) {

                        return 0;

                    }


                    return (
                        dateB -
                        dateA
                    );

                }
            )
            .slice(
                0,
                10
            );


    if (
        recentData.length === 0
    ) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="8"
                    class="empty-table"
                >
                    No records found
                </td>

            </tr>

        `;

    }

    else {

        recentData.forEach(
            item => {

                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>
                        <strong>
                            ${escapeHTML(
                                item.Product_ID
                            )}
                        </strong>
                    </td>

                    <td>
                        ${escapeHTML(
                            item.Sale_Date
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            item.Sales_Rep
                        )}
                    </td>

                    <td>
                        <span class="region-pill">
                            ${escapeHTML(
                                item.Region
                            )}
                        </span>
                    </td>

                    <td>
                        ${escapeHTML(
                            item.Product_Category
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            item.Quantity_Sold
                        )}
                    </td>

                    <td class="table-amount">
                        ${formatCurrency(
                            item.Sales_Amount
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            item.Sales_Channel
                        )}
                    </td>

                `;


                tableBody.appendChild(
                    row
                );

            }
        );

    }


    setText(
        "dashboardRecordCount",
        `${filteredData.length.toLocaleString()} records`
    );

}


// ============================================================
// PARSE DATE
// ============================================================

function parseSaleDate(
    dateString
) {

    if (!dateString) {

        return null;

    }


    const parts =
        String(
            dateString
        ).split("/");


    if (
        parts.length === 3
    ) {

        const day =
            parseInt(
                parts[0]
            );


        const month =
            parseInt(
                parts[1]
            ) - 1;


        const year =
            parseInt(
                parts[2]
            );


        const date =
            new Date(
                year,
                month,
                day
            );


        if (
            !isNaN(
                date.getTime()
            )
        ) {

            return date;

        }

    }


    const fallback =
        new Date(
            dateString
        );


    return isNaN(
        fallback.getTime()
    )
        ? null
        : fallback;

}


// ============================================================
// NUMBER
// ============================================================

function parseNumber(
    value
) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return 0;

    }


    const number =
        parseFloat(
            String(
                value
            ).replace(
                /[^0-9.-]/g,
                ""
            )
        );


    return isNaN(number)
        ? 0
        : number;

}


// ============================================================
// CURRENCY
// ============================================================

function formatCurrency(
    value
) {

    const number =
        parseNumber(
            value
        );


    return "$" +
        number.toLocaleString(
            "en-US",
            {

                minimumFractionDigits:
                    2,

                maximumFractionDigits:
                    2

            }
        );

}


// ============================================================
// COMPACT CURRENCY
// ============================================================

function formatCompactCurrency(
    value
) {

    const number =
        parseNumber(
            value
        );


    if (
        number >= 1000000
    ) {

        return (
            "$" +
            (
                number /
                1000000
            ).toFixed(1) +
            "M"
        );

    }


    if (
        number >= 1000
    ) {

        return (
            "$" +
            (
                number /
                1000
            ).toFixed(1) +
            "K"
        );

    }


    return "$" +
        number.toFixed(0);

}


// ============================================================
// HTML ESCAPE
// ============================================================

function escapeHTML(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(
        value
    )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// ============================================================
// GET VALUE
// ============================================================

function getValue(
    id
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        return "";

    }


    if (element.multiple) {

        return [
            ...element.selectedOptions
        ]
            .map(
                option => option.value
            )
            .filter(
                value => value !== ""
            );

    }


    return element.value || "";

}


// ============================================================
// SET TEXT
// ============================================================

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}


// ============================================================
// SYNC WITH ADMIN PANEL
// ============================================================

window.addEventListener(
    "storage",
    function(event) {

        if (
            event.key !==
            STORAGE_KEY
        ) {

            return;

        }


        try {

            salesData =
                event.newValue
                    ? JSON.parse(
                        event.newValue
                    )
                    : [];


            populateFilters();


            filteredData =
                [...salesData];


            applyFilters();


            console.log(
                "Dashboard synchronized with Admin Panel."
            );

        }

        catch (error) {

            console.error(
                "Dashboard synchronization failed:",
                error
            );

        }

    }
);